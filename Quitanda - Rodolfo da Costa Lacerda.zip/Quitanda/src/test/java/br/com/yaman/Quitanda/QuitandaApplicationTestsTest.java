package br.com.yaman.Quitanda;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class QuitandaApplicationTestsTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
