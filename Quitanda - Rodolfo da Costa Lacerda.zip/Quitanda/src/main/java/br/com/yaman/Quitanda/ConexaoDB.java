package br.com.yaman.Quitanda;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConexaoDB {

	
	
	public static void main(String[] args) {
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@35.203.165.142:1521:xe","QUITANDA","quitandayaman");
			Statement st = con.createStatement();
			String sql = "SELECT * FROM Produto";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next())
				System.out.println(rs.getInt(1) + " " + rs.getString(2));
			con.close();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
	
}
