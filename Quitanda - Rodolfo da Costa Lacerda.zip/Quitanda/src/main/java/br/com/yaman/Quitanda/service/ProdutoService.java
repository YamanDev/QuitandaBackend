package br.com.yaman.Quitanda.service;

import br.com.yaman.Quitanda.dao.entity.Produto;

/**
 * 
 * @author marcus.martins
 *
 */
public interface ProdutoService extends GenericCrudService<Produto> {
	
}