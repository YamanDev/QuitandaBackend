package br.com.yaman.Quitanda.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.yaman.Quitanda.business.GenericCrudBusiness;
import br.com.yaman.Quitanda.business.ProdutoBusiness;
import br.com.yaman.Quitanda.dao.entity.Produto;

@RestController
@RequestMapping(value = "produto")
public class ProdutoController extends CrudControllerBase<Produto> {
	
	@Autowired
	private ProdutoBusiness business;

	@Override
	public GenericCrudBusiness<Produto> getBusinessClass() {		
		return business;
	}

}